import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

/**
 * Design Philosophy: Minimalismo Corporativo Moderno
 * - Clear functional layout with generous whitespace
 * - Professional blue color scheme for financial trust
 * - Real-time calculations with smooth animations
 * - Responsive design that works on all devices
 */

export default function Home() {
  const [costoConexion, setCostoConexion] = useState<number | string>("");
  const [precioVenta, setPrecioVenta] = useState<number | string>("");
  const [utilidad, setUtilidad] = useState<number>(0);
  const [costoAsai, setCostoAsai] = useState<number>(0);
  const [precioAsai, setPrecioAsai] = useState<number>(0);
  const [utilidadAsai, setUtilidadAsai] = useState<number>(0);

  useEffect(() => {
    const costo = parseFloat(String(costoConexion)) || 0;
    const precio = parseFloat(String(precioVenta)) || 0;

    // Cálculo para Conexiones Americanas
    let utilidadCalc = 0;
    if (costo > 0) {
      utilidadCalc = ((precio - costo) / costo) * 100;
    }
    setUtilidad(utilidadCalc);

    // Cálculo para ASAI (35% del costo, precio duplicado)
    const costoAsaiCalc = costo * 0.35;
    const precioAsaiCalc = costoAsaiCalc * 2;
    let utilidadAsaiCalc = 0;
    if (costoAsaiCalc > 0) {
      utilidadAsaiCalc = ((precioAsaiCalc - costoAsaiCalc) / costoAsaiCalc) * 100;
    }

    setCostoAsai(costoAsaiCalc);
    setPrecioAsai(precioAsaiCalc);
    setUtilidadAsai(utilidadAsaiCalc);
  }, [costoConexion, precioVenta]);

  return (
    <div className="min-h-screen hero-bg flex flex-col">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-border sticky top-0 z-10">
        <div className="container py-6">
          <h1 className="font-display text-3xl text-foreground">
            Calculadora de Utilidad
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Conexiones Americanas vs ASAI
          </p>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Conexiones Americanas Card */}
          <Card className="card-calculator p-8">
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-xl text-foreground mb-6">
                  Conexiones Americanas
                </h2>
              </div>

              {/* Input Group 1 */}
              <div className="space-y-2">
                <Label
                  htmlFor="costo"
                  className="text-sm font-medium text-foreground"
                  style={{ fontFamily: '"Inter", sans-serif', fontWeight: 500 }}
                >
                  Costo de Conexión Americana
                </Label>
                <Input
                  id="costo"
                  type="number"
                  placeholder="Ej: 1500"
                  value={costoConexion}
                  onChange={(e) => setCostoConexion(e.target.value)}
                  className="text-base"
                  style={{ fontFamily: '"Inter", sans-serif' }}
                />
              </div>

              {/* Input Group 2 */}
              <div className="space-y-2">
                <Label
                  htmlFor="precio"
                  className="text-sm font-medium text-foreground"
                  style={{ fontFamily: '"Inter", sans-serif', fontWeight: 500 }}
                >
                  Precio de Venta
                </Label>
                <Input
                  id="precio"
                  type="number"
                  placeholder="Ej: 3000"
                  value={precioVenta}
                  onChange={(e) => setPrecioVenta(e.target.value)}
                  className="text-base"
                  style={{ fontFamily: '"Inter", sans-serif' }}
                />
              </div>

              {/* Result */}
              <div className="bg-gradient-to-r from-primary/5 to-primary/10 rounded-lg p-6 border border-primary/20 mt-8">
                <p
                  className="text-sm text-muted-foreground mb-2"
                  style={{ fontFamily: '"Inter", sans-serif' }}
                >
                  Margen de Utilidad
                </p>
                <p className="font-display text-4xl text-primary">
                  {utilidad.toFixed(2)}%
                </p>
              </div>
            </div>
          </Card>

          {/* ASAI Comparison Card */}
          <Card className="card-calculator p-8 border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
            <div className="space-y-6">
              <div>
                <h2 className="font-display text-xl text-primary mb-6">
                  Con ASAI
                </h2>
              </div>

              {/* Results Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Costo ASAI */}
                <div className="bg-white/60 rounded-lg p-4 border border-border/50">
                  <p
                    className="text-xs text-muted-foreground mb-2"
                    style={{ fontFamily: '"Inter", sans-serif' }}
                  >
                    Costo
                  </p>
                  <p className="font-display text-2xl text-foreground">
                    ${costoAsai.toFixed(2)}
                  </p>
                </div>

                {/* Precio ASAI */}
                <div className="bg-white/60 rounded-lg p-4 border border-border/50">
                  <p
                    className="text-xs text-muted-foreground mb-2"
                    style={{ fontFamily: '"Inter", sans-serif' }}
                  >
                    Precio de Venta Sugerido
                  </p>
                  <p className="font-display text-2xl text-foreground">
                    ${precioAsai.toFixed(2)}
                  </p>
                </div>

                {/* Utilidad ASAI */}
                <div className="bg-gradient-to-br from-primary/10 to-primary/5 rounded-lg p-4 border border-primary/20">
                  <p
                    className="text-xs text-muted-foreground mb-2"
                    style={{ fontFamily: '"Inter", sans-serif' }}
                  >
                    Margen de Utilidad
                  </p>
                  <p className="font-display text-2xl text-primary">
                    {utilidadAsai.toFixed(2)}%
                  </p>
                </div>
              </div>
            </div>
          </Card>

          {/* Footer Note */}
          <div
            className="text-center text-xs text-muted-foreground"
            style={{ fontFamily: '"Inter", sans-serif' }}
          >
            <p>
              Los cálculos se actualizan automáticamente mientras ingresas los
              valores.
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
